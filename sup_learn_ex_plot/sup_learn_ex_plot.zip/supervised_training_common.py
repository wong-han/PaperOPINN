import json
import os
import time

import numpy as np
import torch


def _save_json(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, indent=2)


def _dataset_loss(model, x_tensor, u_tensor, batch_size):
    model.eval()
    squared_error_sum = 0.0
    element_count = 0
    with torch.no_grad():
        for start in range(0, len(x_tensor), batch_size):
            prediction = model(x_tensor[start:start + batch_size])
            target = u_tensor[start:start + batch_size]
            squared_error_sum += torch.sum((prediction - target) ** 2).item()
            element_count += target.numel()
    model.train()
    return squared_error_sum / element_count


def train_from_saved_trajectories(
    *,
    model,
    optimizer,
    device,
    experiment_name,
    x_path,
    u_path,
    model_path,
    result_path,
    split_seed,
    validation_fraction,
    requested_batch_size,
    evaluation_interval,
    early_stop_patience,
    minimum_training_steps,
    maximum_training_steps,
    minimum_relative_improvement,
):
    if not os.path.exists(x_path) or not os.path.exists(u_path):
        raise FileNotFoundError(
            "Shared dataset not found. Run the corresponding problem-specific "
            "dataset-generation script first.\n"
            f"Expected:\n  {x_path}\n  {u_path}"
        )

    x_trajectories = np.load(x_path, allow_pickle=True)
    u_trajectories = np.load(u_path, allow_pickle=True)
    if len(x_trajectories) != len(u_trajectories) or len(x_trajectories) < 2:
        raise ValueError("The shared state/action trajectory files are inconsistent or too small.")

    split_rng = np.random.default_rng(split_seed)
    trajectory_indices = split_rng.permutation(len(x_trajectories))
    validation_count = max(1, int(round(len(trajectory_indices) * validation_fraction)))
    validation_indices = trajectory_indices[:validation_count]
    training_indices = trajectory_indices[validation_count:]

    x_train = np.vstack([x_trajectories[index] for index in training_indices]).astype(np.float32)
    u_train = np.vstack([u_trajectories[index] for index in training_indices]).astype(np.float32)
    x_validation = np.vstack([x_trajectories[index] for index in validation_indices]).astype(np.float32)
    u_validation = np.vstack([u_trajectories[index] for index in validation_indices]).astype(np.float32)

    x_train_tensor = torch.from_numpy(x_train).to(device)
    u_train_tensor = torch.from_numpy(u_train).to(device)
    x_validation_tensor = torch.from_numpy(x_validation).to(device)
    u_validation_tensor = torch.from_numpy(u_validation).to(device)
    batch_size = min(requested_batch_size, len(x_train))

    print(
        f"Loaded shared dataset: train={len(training_indices)} trajectories/{len(x_train)} samples, "
        f"validation={len(validation_indices)} trajectories/{len(x_validation)} samples."
    )
    print("--- Training Network ---")

    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.synchronize()
    training_start = time.perf_counter()

    step = 0
    no_improvement_count = 0
    training_loss_history = []
    validation_loss_history = []
    best_validation_loss = float("inf")
    early_stop_reference = float("inf")
    best_state = None
    stop_reason = "max_steps"
    training_loss_evaluation_seconds = 0.0

    while step < maximum_training_steps:
        step += 1
        batch_indices = np.random.choice(len(x_train), batch_size)
        prediction = model(x_train_tensor[batch_indices])
        loss = torch.nn.functional.mse_loss(prediction, u_train_tensor[batch_indices])
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        training_batch_loss = loss.item()

        if step % evaluation_interval != 0:
            continue

        training_evaluation_start = time.perf_counter()
        training_full_loss = _dataset_loss(
            model, x_train_tensor, u_train_tensor, batch_size
        )
        training_loss_evaluation_seconds += (
            time.perf_counter() - training_evaluation_start
        )
        validation_loss = _dataset_loss(
            model, x_validation_tensor, u_validation_tensor, batch_size
        )
        training_loss_history.append(training_full_loss)
        validation_loss_history.append(validation_loss)

        if validation_loss < best_validation_loss:
            best_validation_loss = validation_loss
            best_state = {
                name: value.detach().cpu().clone()
                for name, value in model.state_dict().items()
            }

        relative_improvement = None
        if np.isinf(early_stop_reference):
            early_stop_reference = validation_loss
            no_improvement_count = 0
        else:
            relative_improvement = (
                early_stop_reference - validation_loss
            ) / max(abs(early_stop_reference), 1e-12)
            if relative_improvement >= minimum_relative_improvement:
                early_stop_reference = validation_loss
                no_improvement_count = 0
            else:
                no_improvement_count = min(no_improvement_count + 1, early_stop_patience)

        improvement_text = (
            "n/a" if relative_improvement is None else f"{relative_improvement:.3%}"
        )
        print(
            f"Step {step}, train_batch={training_batch_loss:.6g}, "
            f"train_full={training_full_loss:.6g}, val={validation_loss:.6g}, "
            f"improvement_vs_reference={improvement_text}, "
            f"no_improvement={no_improvement_count}/{early_stop_patience}"
        )

        if step >= minimum_training_steps and no_improvement_count >= early_stop_patience:
            stop_reason = "validation_early_stopping"
            print("Training stopped because the validation loss no longer decreased sufficiently.")
            break

    if best_state is not None:
        model.load_state_dict(best_state)
    if str(device).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.synchronize()
    training_wall_clock_seconds = time.perf_counter() - training_start
    training_seconds = (
        training_wall_clock_seconds - training_loss_evaluation_seconds
    )

    selected_training_loss = _dataset_loss(
        model, x_train_tensor, u_train_tensor, batch_size
    )
    selected_validation_loss = _dataset_loss(
        model, x_validation_tensor, u_validation_tensor, batch_size
    )

    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    torch.save(model.state_dict(), model_path)

    record = {
        "experiment": experiment_name,
        "seed": split_seed,
        "device": str(device),
        "dataset_state_file": os.path.abspath(x_path),
        "dataset_action_file": os.path.abspath(u_path),
        "trajectories": len(x_trajectories),
        "training_trajectories": len(training_indices),
        "validation_trajectories": len(validation_indices),
        "training_samples": len(x_train),
        "validation_samples": len(x_validation),
        "validation_fraction": validation_fraction,
        "training_trajectory_indices": training_indices.tolist(),
        "validation_trajectory_indices": validation_indices.tolist(),
        "batch_size": batch_size,
        "steps": step,
        "selected_model_training_mse": selected_training_loss,
        "selected_model_validation_mse": selected_validation_loss,
        "best_validation_mse": best_validation_loss,
        "early_stop_reference_mse": early_stop_reference,
        "final_no_improvement_evaluations": no_improvement_count,
        "monitored_training_mse": training_loss_history,
        "monitored_validation_mse": validation_loss_history,
        "monitor_steps": [
            evaluation_interval * (index + 1)
            for index in range(len(validation_loss_history))
        ],
        "stop_reason": stop_reason,
        "training_seconds": training_seconds,
        "training_wall_clock_seconds": training_wall_clock_seconds,
        "training_loss_evaluation_seconds": training_loss_evaluation_seconds,
        "early_stopping_rule": {
            "evaluation_interval_steps": evaluation_interval,
            "reference": "last_validation_loss_with_significant_improvement",
            "patience_evaluations": early_stop_patience,
            "patience_steps": early_stop_patience * evaluation_interval,
            "minimum_relative_improvement": minimum_relative_improvement,
            "minimum_training_steps": minimum_training_steps,
            "maximum_training_steps": maximum_training_steps,
        },
    }
    _save_json(result_path, record)
    print(
        f"Model saved to {model_path}. Training time: {training_seconds:.2f} seconds "
        f"(wall clock: {training_wall_clock_seconds:.2f} seconds; "
        f"train_full diagnostics: {training_loss_evaluation_seconds:.2f} seconds)."
    )
    return record
